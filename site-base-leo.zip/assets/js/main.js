
const toggle = document.getElementById('nav-toggle');
const list = document.getElementById('nav-list');
if(toggle){
  toggle.addEventListener('click', ()=>{
    list.classList.toggle('show');
  });
}
